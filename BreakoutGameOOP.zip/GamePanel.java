import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class GamePanel extends JPanel implements KeyListener {
    private Timer timer;
    private Paddle paddle;
    private Ball ball;
    private List<Brick> bricks;
    private boolean paused = false;
    private boolean gameOver = false;
    private int lives = 3;
    private int score = 0;

    public GamePanel() {
        setPreferredSize(new Dimension(Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT));
        setBackground(Color.WHITE);
        setFocusable(true);
        addKeyListener(this);
        initGameObjects();

        timer = new Timer(Constants.TIMER_DELAY_MS, e -> {
            if (!paused && !gameOver) update();
            repaint();
        });
    }

    public void startGame() { timer.start(); }

    private void initGameObjects() {
        paddle = new Paddle(Constants.WINDOW_WIDTH/2 - 60, Constants.WINDOW_HEIGHT - 50, 120, 12);
        ball = new Ball(Constants.WINDOW_WIDTH/2 - 8, Constants.WINDOW_HEIGHT - 80, 16, Constants.BALL_SPEED);
        createBricks();
        paused = false;
        gameOver = false;
        lives = 3;
        score = 0;
    }

    private void createBricks() {
        bricks = new ArrayList<>();
        int rows = Constants.LEVELS, cols = Constants.BRICK_COLUMNS, padding = 4;
        int brickWidth = (Constants.WINDOW_WIDTH - padding * (cols + 1)) / cols;
        int brickHeight = 24;
        Color[] colors = { Color.ORANGE, Color.MAGENTA, Color.CYAN, Color.GREEN, Color.PINK };
        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                bricks.add(new Brick(padding + c*(brickWidth+padding), 40 + r*(brickHeight+padding),
                        brickWidth, brickHeight, colors[r % colors.length]));
    }

    private void update() {
        paddle.update(this);
        ball.update(this);
        if (bricks.stream().allMatch(Brick::isDestroyed)) gameOver = true;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        paddle.draw(g2); ball.draw(g2);
        bricks.forEach(b -> b.draw(g2));
        g2.setColor(Color.BLACK);
        g2.setFont(new Font("SansSerif", Font.BOLD, 16));
        g2.drawString("Score: " + score, 10, 20);
        g2.drawString("Lives: " + lives, Constants.WINDOW_WIDTH - 100, 20);
        if (paused) { g2.setFont(new Font("SansSerif", Font.BOLD, 36)); g2.drawString("PAUSED", 340, 300); }
        if (gameOver) {
            g2.setFont(new Font("SansSerif", Font.BOLD, 36));
            g2.drawString(isWin() ? "YOU WIN!" : "GAME OVER", 300, 280);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 20));
            g2.drawString("Press R to restart", 330, 320);
        }
    }

    public Paddle getPaddle() { return paddle; }
    public List<Brick> getBricks() { return bricks; }
    public void loseLife() { if (--lives <= 0) gameOver = true; else ball.resetTo(400, 500); }
    public void addScore(int s) { score += s; }
    public boolean isWin() { return bricks.stream().allMatch(Brick::isDestroyed); }

    @Override public void keyTyped(KeyEvent e) {}
    @Override public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT, KeyEvent.VK_A -> paddle.moveLeft();
            case KeyEvent.VK_RIGHT, KeyEvent.VK_D -> paddle.moveRight();
            case KeyEvent.VK_SPACE -> paused = !paused;
            case KeyEvent.VK_R -> initGameObjects();
        }
    }
    @Override public void keyReleased(KeyEvent e) { paddle.stop(); }
}
