# Breakout (Beginner OOP Java Game)

## Overview
A simple **Breakout**-style game implemented in Java Swing.  
Move the paddle to bounce the ball, break bricks, and score points!

This project is good for beginners to explore:
- Object-Oriented Design (inheritance, encapsulation, polymorphism)
- GUI programming with Swing
- Basic game loops and collision detection

---

## Controls
- **Left / A:** Move paddle left  
- **Right / D:** Move paddle right  
- **Space:** Pause / unpause  
- **R:** Restart the game

---

## Run Instructions
1. Compile all java files (`javac *.java`)
2. Run the GameMain (`java GameMain`)
3. Enjoy!

---

## Extend This Project
Ideas for learners to complete on their own:
- Change the starting number of levels or columns
- Count and display the number of bricks broken
- Speed up the ball after a certain number of broken bricks
- High score tracking in a text file

Extensions for completion in partnership with AI:
- Allow the user to select the number of levels and columns at start
- Add special bricks (e.g., bricks that break the bricks around them)
- Add powerups (e.g., items the paddle can "catch" for extra points)
- Allow the user to speed up or slow down the ball with key presses

---

## License
November 2025
Generated using Generative AI (ChatGPT). Modified using human-intelligence.
This project is open for educational and personal use. Share and modify freely!
