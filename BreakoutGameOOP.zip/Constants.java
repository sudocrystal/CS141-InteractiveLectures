public class Constants {
    public static final int WINDOW_WIDTH = 800;
    public static final int WINDOW_HEIGHT = 600;
    public static final int TIMER_DELAY_MS = 16; // ~60 FPS
    public static final int PADDLE_SPEED = 6;
    public static final int BALL_SPEED = 4;
    public static final int BRICK_COLUMNS = 5;
    public static final int LEVELS = 5;
}
