import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Ball extends GameObject {
    private double vx, vy;
    private int speed;

    public Ball(int x, int y, int diameter, int speed) {
        super(x, y, diameter, diameter);
        this.speed = speed;
        vx = speed * 0.7;
        vy = -speed * 0.7;
    }
    
    public int getSpeed() { return this.speed; }
    
    public void setSpeed(int speed) { 
        this.speed = speed; 
        vx = speed * 0.7;
        vy = -speed * 0.7;
    }

    @Override
    public void update(GamePanel panel) {
        x += vx;
        y += vy;

        if (x <= 0) { x = 0; vx = -vx; }
        else if (x + width >= panel.getWidth()) { x = panel.getWidth() - width; vx = -vx; }
        if (y <= 0) { y = 0; vy = -vy; }
        if (y > panel.getHeight()) panel.loseLife();

        Paddle paddle = panel.getPaddle();
        if (paddle != null && getBounds().intersects(paddle.getBounds())) {
            y = paddle.y - height;
            vy = -Math.abs(vy);
            double hitPos = (x + width/2.0) - (paddle.x + paddle.width/2.0);
            vx += hitPos * 0.05;
            double currentSpeed = Math.sqrt(vx*vx + vy*vy);
            vx = vx / currentSpeed * speed;
            vy = vy / currentSpeed * speed;
        }

        for (Brick b : panel.getBricks()) {
            if (!b.isDestroyed() && getBounds().intersects(b.getBounds())) {
                b.destroy();
                panel.addScore(10);
                vy = -vy;
                break;
            }
        }
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(Color.RED);
        g.fillOval(x, y, width, height);
    }

    public void resetTo(int cx, int cy) {
        x = cx - width/2;
        y = cy - height/2;
        vx = speed * 0.7;
        vy = -speed * 0.7;
    }
}
