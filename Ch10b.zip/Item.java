public class Item {
   //fields
   
   //constructors
   
   //accessors
   
   //mutators
   
   //toString --> format could/should be "yogurt (5)"

}