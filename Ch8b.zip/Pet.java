public class Pet {
   // fields
   private String name;
   private String species;
   private String breed;

   // constructor(s)
   public Pet() {
   }
   
   public Pet(String name, String species, String breed) {
   }

   // accessors

   // mutators

   // toString

}