import java.awt.Color;
import java.awt.Graphics2D;

public class Paddle extends GameObject {
    private int speed = 0;

    public Paddle(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void moveLeft()  { speed = -Constants.PADDLE_SPEED; }
    public void moveRight() { speed =  Constants.PADDLE_SPEED; }
    public void stop()      { speed = 0; }

    @Override
    public void update(GamePanel panel) {
        x += speed;
        if (x < 0) x = 0;
        if (x + width > panel.getWidth()) x = panel.getWidth() - width;
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(Color.DARK_GRAY);
        g.fillRect(x, y, width, height);
    }
}
